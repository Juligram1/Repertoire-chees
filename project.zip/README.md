Juligram Repertoire, step 1. Built by GitHub Actions: upload this zip as `project.zip` to your repo root.

package com.juligram.repertoire

import android.Manifest
import android.app.Activity
import android.content.Context
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import com.github.bhlangonijr.chesslib.*
import kotlinx.coroutines.launch

private val GLYPH = mapOf("k" to "♚", "q" to "♛", "r" to "♜", "b" to "♝", "n" to "♞", "p" to "♟")
private val LIGHT = Color(0xFFDDEBD5)
private val DARK = Color(0xFF4E8F5A)

@Composable
fun BoardView(fen: String, flipped: Boolean, selected: Square?, onTap: (Square) -> Unit) {
    val board = remember(fen) { Board().apply { loadFromFen(fen) } }
    Column(Modifier.fillMaxWidth().aspectRatio(1f)) {
        val ranks = if (flipped) 0..7 else 7 downTo 0
        val files = if (flipped) 7 downTo 0 else 0..7
        for (r in ranks) Row(Modifier.weight(1f)) {
            for (f in files) {
                val sq = Square.encode(Rank.allRanks[r], File.allFiles[f])
                val bg = when {
                    sq == selected -> Color(0xFFD9C84A)
                    (r + f) % 2 == 1 -> LIGHT
                    else -> DARK
                }
                Box(Modifier.weight(1f).fillMaxHeight().background(bg).clickable { onTap(sq) }, Alignment.Center) {
                    val p = board.getPiece(sq)
                    if (p != Piece.NONE) {
                        val s = p.fenSymbol
                        Text(
                            GLYPH[s.lowercase()] ?: "",
                            style = TextStyle(
                                fontSize = 30.sp,
                                color = if (s[0].isUpperCase()) Color.White else Color(0xFF111111),
                                shadow = Shadow(Color.Black, Offset.Zero, 6f)
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(dao: RepDao, onOpen: (RepertoireEntity) -> Unit) {
    val reps by dao.repertoires().collectAsState(emptyList())
    val scope = rememberCoroutineScope()
    var adding by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Juligram Repertoire", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            TextButton({ settings = true }) { Text("🔔") }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(reps, key = { it.id }) { r ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onOpen(r) }) {
                    Text(
                        "${r.name}  ·  ${if (r.isWhite) "White" else "Black"}",
                        Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
        Button({ adding = true }, Modifier.fillMaxWidth()) { Text("New repertoire") }
    }
    if (adding) {
        var name by remember { mutableStateOf("") }
        var white by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { adding = false },
            confirmButton = {
                TextButton({
                    if (name.isNotBlank()) scope.launch { dao.createRepertoire(name.trim(), white) }
                    adding = false
                }) { Text("Create") }
            },
            title = { Text("New repertoire") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Playing White", Modifier.weight(1f))
                        Switch(white, { white = it })
                    }
                }
            }
        )
    }
    if (settings) ReminderDialog { settings = false }
}

@Composable
fun EditorScreen(dao: RepDao, rep: RepertoireEntity, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var path by remember { mutableStateOf(listOf(rep.rootPositionId)) }
    val cur = path.last()
    val fen by produceState("", cur) { value = dao.fen(cur) }
    val moves by remember(cur) { dao.movesFrom(rep.id, cur) }.collectAsState(emptyList())
    var sel by remember { mutableStateOf<Square?>(null) }
    var noteFor by remember { mutableStateOf<RepMoveEntity?>(null) }
    BackHandler(path.size > 1) { path = path.dropLast(1) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("‹ Back") }
            Text(rep.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            TextButton({ path = path.dropLast(1); sel = null }, enabled = path.size > 1) { Text("Undo") }
        }
        if (fen.isNotEmpty()) BoardView(fen, flipped = !rep.isWhite, selected = sel) { sq ->
            val s = sel
            if (s == null) sel = sq else {
                val b = Board().apply { loadFromFen(fen) }
                val mv = b.legalMoves().firstOrNull {
                    it.from == s && it.to == sq && (it.promotion == Piece.NONE || it.promotion.pieceType == PieceType.QUEEN)
                }
                if (mv != null) { sel = null; scope.launch { path = path + dao.playMove(rep.id, cur, mv) } }
                else sel = sq
            }
        }
        if (moves.isEmpty()) Text("No moves here yet. Play one on the board.", Modifier.padding(top = 12.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(moves, key = { it.id }) { m ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ path = path + m.toPositionId; sel = null }) {
                        Text(m.san, style = MaterialTheme.typography.titleMedium)
                    }
                    Text(m.note, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    TextButton({ scope.launch { dao.setMain(rep.id, cur, m.id) } }) { Text(if (m.isMain) "★" else "☆") }
                    TextButton({ noteFor = m }) { Text("✎") }
                    TextButton({ scope.launch { dao.deleteMove(m.id) } }) { Text("✕") }
                }
            }
        }
    }
    noteFor?.let { m ->
        var text by remember(m.id) { mutableStateOf(m.note) }
        AlertDialog(
            onDismissRequest = { noteFor = null },
            confirmButton = { TextButton({ scope.launch { dao.setNote(m.id, text) }; noteFor = null }) { Text("Save") } },
            title = { Text("Note for ${m.san}") },
            text = { OutlinedTextField(text, { text = it }) }
        )
    }
}

@Composable
fun ReminderDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    var on by remember { mutableStateOf(prefs.getBoolean("rem_on", false)) }
    var hour by remember { mutableStateOf(prefs.getInt("rem_hour", 18)) }
    fun save() {
        prefs.edit().putBoolean("rem_on", on).putInt("rem_hour", hour).apply()
        if (on) Reminder.schedule(ctx, hour) else Reminder.cancel(ctx)
    }
    AlertDialog(
        onDismissRequest = { save(); onClose() },
        confirmButton = { TextButton({ save(); onClose() }) { Text("Done") } },
        title = { Text("Daily reminder") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Remind me to practice", Modifier.weight(1f))
                    Switch(on, {
                        on = it
                        if (it && Build.VERSION.SDK_INT >= 33)
                            ActivityCompat.requestPermissions(ctx as Activity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                    })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ hour = (hour + 23) % 24 }) { Text("−") }
                    Text("%02d:00".format(hour))
                    TextButton({ hour = (hour + 1) % 24 }) { Text("+") }
                }
            }
        }
    )
}

package com.juligram.repertoire

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = Db.get(this).dao()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF66BB6A), background = Color(0xFF0F1A12),
                    surface = Color(0xFF16241A), onBackground = Color(0xFFE6F2E8), onSurface = Color(0xFFE6F2E8)
                )
            ) {
                Surface(Modifier.fillMaxSize().safeDrawingPadding(), color = MaterialTheme.colorScheme.background) {
                    var open by remember { mutableStateOf<RepertoireEntity?>(null) }
                    BackHandler(open != null) { open = null }
                    val rep = open
                    if (rep == null) HomeScreen(dao) { open = it } else EditorScreen(dao, rep) { open = null }
                }
            }
        }
    }
}

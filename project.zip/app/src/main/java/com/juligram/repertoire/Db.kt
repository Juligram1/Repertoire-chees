package com.juligram.repertoire

import android.content.Context
import androidx.room.*
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.move.Move
import com.github.bhlangonijr.chesslib.move.MoveList
import kotlinx.coroutines.flow.Flow

const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
// Keep only placement/side/castling/en-passant so transpositions share one node.
fun normFen(fen: String) = fen.split(" ").take(4).joinToString(" ") + " 0 1"

@Entity(tableName = "pos", indices = [Index(value = ["fen"], unique = true)])
data class PositionEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val fen: String)

@Entity(tableName = "repertoire")
data class RepertoireEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val isWhite: Boolean, val rootPositionId: Long
)

@Entity(
    tableName = "rep_move",
    indices = [Index(value = ["repertoireId", "fromPositionId", "san"], unique = true)]
)
data class RepMoveEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val repertoireId: Long, val fromPositionId: Long, val toPositionId: Long,
    val san: String, val isMain: Boolean = false, val note: String = ""
)

@Dao
abstract class RepDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) abstract suspend fun insertPosition(p: PositionEntity): Long
    @Query("SELECT id FROM pos WHERE fen = :fen") abstract suspend fun positionId(fen: String): Long?
    @Query("SELECT fen FROM pos WHERE id = :id") abstract suspend fun fen(id: Long): String
    @Insert abstract suspend fun insertRepertoire(r: RepertoireEntity): Long
    @Query("SELECT * FROM repertoire ORDER BY id") abstract fun repertoires(): Flow<List<RepertoireEntity>>
    @Query("SELECT * FROM rep_move WHERE repertoireId = :rid AND fromPositionId = :pid ORDER BY isMain DESC, id")
    abstract fun movesFrom(rid: Long, pid: Long): Flow<List<RepMoveEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) abstract suspend fun insertMove(m: RepMoveEntity): Long
    @Query("SELECT COUNT(*) FROM rep_move WHERE repertoireId = :rid AND fromPositionId = :pid")
    abstract suspend fun countFrom(rid: Long, pid: Long): Int
    @Query("UPDATE rep_move SET isMain = (id = :id) WHERE repertoireId = :rid AND fromPositionId = :pid")
    abstract suspend fun setMain(rid: Long, pid: Long, id: Long)
    @Query("UPDATE rep_move SET note = :note WHERE id = :id") abstract suspend fun setNote(id: Long, note: String)
    @Query("DELETE FROM rep_move WHERE id = :id") abstract suspend fun deleteMove(id: Long)

    @Transaction
    open suspend fun createRepertoire(name: String, white: Boolean) {
        insertPosition(PositionEntity(fen = START_FEN))
        insertRepertoire(RepertoireEntity(name = name, isWhite = white, rootPositionId = positionId(START_FEN)!!))
    }

    /** Adds [move] from position [fromId] to the repertoire; returns the resulting position id. */
    @Transaction
    open suspend fun playMove(rid: Long, fromId: Long, move: Move): Long {
        val fromFen = fen(fromId)
        val san = MoveList(fromFen).also { it.add(move) }.toSanArray().last()
        val b = Board().also { it.loadFromFen(fromFen); it.doMove(move) }
        val toFen = normFen(b.fen)
        insertPosition(PositionEntity(fen = toFen))
        val toId = positionId(toFen)!!
        insertMove(
            RepMoveEntity(
                repertoireId = rid, fromPositionId = fromId, toPositionId = toId, san = san,
                isMain = countFrom(rid, fromId) == 0
            )
        )
        return toId
    }
}

@Database(entities = [PositionEntity::class, RepertoireEntity::class, RepMoveEntity::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): RepDao

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "rep.db").build().also { inst = it }
        }
    }
}
